"""Fetcher for bundled CLI tool binaries.

`pip install headroom-ai` pulls `ast-grep-cli` as a proper PyPI binary wheel
(core dependency), so ast-grep is always on PATH. The other two high-value
tools — `difft` (difftastic) and `scc` — are fetched from pinned upstream
GitHub releases at proxy startup, verified, cached per-user, and exec'd.

Supported platforms: linux (glibc + musl) x86_64/aarch64, macOS x86_64/arm64,
Windows x86_64. Unsupported platforms raise PlatformNotSupported; callers in
the compression pipeline should fall back to their non-accelerated path.

Every asset this package ships is pinned by SHA-256 in `tools.json`, and the
tools-hash-refresh CI gate fails the build if a pin is missing or stale. So
verification fails closed: a download whose URL carries no pin is refused
rather than trusted on transport (HTTPS) alone.

Env vars:
    HEADROOM_BINARIES_MIRROR   base URL that replaces https://github.com
    HEADROOM_BINARIES_CACHE    override cache dir
    HEADROOM_BINARIES_OFFLINE  if set, never reach the network
    HEADROOM_BINARIES_ALLOW_UNVERIFIED
        Escape hatch: if set, skip SHA-256 verification entirely and accept
        whatever the mirror served. This disables Headroom's only defence
        against a tampered or substituted binary, so it is announced on
        stderr every time it takes effect. Intended for developers testing a
        locally built asset or an off-registry version; never set it in CI or
        in production. Pin the asset in `tools.json` instead.
"""

from __future__ import annotations

import functools
import glob
import hashlib
import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import ssl

from headroom._subprocess import run
from headroom.offline import guard_egress

logger = logging.getLogger(__name__)

__all__ = [
    "BinaryError",
    "BinaryFetchError",
    "PlatformNotSupported",
    "Sha256Mismatch",
    "UnpinnedDownload",
    "OfflineError",
    "PlatformKey",
    "detect_platform",
    "cache_dir",
    "resolve",
    "which",
    "status",
    "ensure_tools",
]


# ---------- Exceptions ---------------------------------------------------- #


class BinaryError(Exception):
    """Base exception for the binaries module."""


class BinaryFetchError(BinaryError):
    """Raised when a download fails or an archive cannot be extracted."""


class PlatformNotSupported(BinaryError):
    """Raised when the current OS/arch is not covered by a tool's registry."""


class Sha256Mismatch(BinaryError):
    """Raised when a downloaded asset's SHA256 does not match the pin."""


class UnpinnedDownload(BinaryError):
    """Raised when a downloaded asset has no SHA256 pin to verify it against.

    Every shipped asset is pinned (tools-hash-refresh CI gate), so a missing
    pin means an off-registry fetch — a version override, a hand-edited
    registry, or a URL an installer built that the registry does not describe.
    Accepting it would silently downgrade integrity to transport trust, so we
    refuse. Pin the asset in `tools.json`, or set
    HEADROOM_BINARIES_ALLOW_UNVERIFIED=1 to accept the risk explicitly.
    """


class OfflineError(BinaryError):
    """Raised when a network fetch is required but HEADROOM_BINARIES_OFFLINE is set."""


# ---------- Platform detection -------------------------------------------- #


@dataclass(frozen=True)
class PlatformKey:
    os: str  # "linux" | "darwin" | "windows"
    arch: str  # "x86_64" | "aarch64"
    libc: str  # "gnu" | "musl" | "n/a"

    def key(self) -> str:
        # Compact form used as registry lookup key and cache subdirectory.
        if self.os == "linux":
            return f"{self.os}-{self.arch}-{self.libc}"
        return f"{self.os}-{self.arch}"


def _machine_to_arch(machine: str) -> str:
    m = machine.lower()
    if m in ("x86_64", "amd64"):
        return "x86_64"
    if m in ("aarch64", "arm64"):
        return "aarch64"
    return m  # return as-is; lookup will fail cleanly with PlatformNotSupported


def _is_musl() -> bool:
    """Best-effort musl detection on Linux. Never raises.

    First: ask `ldd --version` (returns 'musl' on Alpine/Void).
    Fallback: check for the musl dynamic loader at /lib/ld-musl-*.so.1,
    which is present on Alpine even when `ldd` is absent.
    """
    try:
        out = run(
            ["ldd", "--version"],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
        if "musl" in (out.stdout + out.stderr).lower():
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    # Fallback: musl ships a distinctive dynamic loader.
    if glob.glob("/lib/ld-musl-*.so.1") or glob.glob("/lib64/ld-musl-*.so.1"):
        return True
    return False


@functools.lru_cache(maxsize=1)
def detect_platform() -> PlatformKey:
    arch = _machine_to_arch(platform.machine())
    if sys.platform.startswith("linux"):
        return PlatformKey("linux", arch, "musl" if _is_musl() else "gnu")
    if sys.platform == "darwin":
        return PlatformKey("darwin", arch, "n/a")
    if sys.platform.startswith("win"):
        return PlatformKey("windows", arch, "n/a")
    return PlatformKey(sys.platform, arch, "n/a")


# ---------- Cache dir ----------------------------------------------------- #


def _is_writable_dir(path: Path) -> bool:
    try:
        mode = path.stat().st_mode
    except OSError:
        return False
    return path.is_dir() and bool(mode & 0o222)


def _has_writable_existing_parent(path: Path) -> bool:
    current = path
    while not current.exists():
        parent = current.parent
        if parent == current:
            return False
        current = parent
    return _is_writable_dir(current)


def cache_dir() -> Path:
    override = os.environ.get("HEADROOM_BINARIES_CACHE")
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform.startswith("win"):
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "headroom" / "bin"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Caches" / "headroom" / "bin"
    xdg = os.environ.get("XDG_CACHE_HOME")
    base = Path(xdg) if xdg else Path.home() / ".cache"
    return base / "headroom" / "bin"


# ---------- Registry ------------------------------------------------------ #


_REGISTRY_PATH = Path(__file__).parent / "tools.json"


@functools.lru_cache(maxsize=1)
def _registry() -> dict[str, Any]:
    with _REGISTRY_PATH.open("r", encoding="utf-8") as f:
        data: dict[str, Any] = json.load(f)
    return data


def _tool_entry(tool: str) -> dict[str, Any]:
    reg = _registry()
    tools: dict[str, Any] = reg.get("tools", {})
    if tool not in tools:
        raise KeyError(f"unknown tool {tool!r}; known: {sorted(tools)}")
    entry: dict[str, Any] = tools[tool]
    return entry


def _is_pypi_tool(tool: str) -> bool:
    entry = _tool_entry(tool)
    return entry.get("version") == "pypi" or not entry.get("assets")


def _asset_for_platform(tool: str, plat: PlatformKey) -> dict[str, Any]:
    entry = _tool_entry(tool)
    if _is_pypi_tool(tool):
        raise PlatformNotSupported(
            f"{tool}: distributed via PyPI only; `pip install headroom-ai` "
            f"should have placed `{entry.get('binary', tool)}` on PATH."
        )
    assets: dict[str, Any] = entry.get("assets", {})
    asset: dict[str, Any] | None = assets.get(plat.key())
    if asset is None:
        supported = sorted(assets.keys())
        raise PlatformNotSupported(
            f"{tool}: no prebuilt binary for {plat.key()}; supported: {supported}"
        )
    return asset


def _mirror_url(url: str) -> str:
    mirror = os.environ.get("HEADROOM_BINARIES_MIRROR")
    if not mirror:
        return url
    if not mirror.startswith("https://"):
        raise BinaryFetchError(f"HEADROOM_BINARIES_MIRROR must use https:// (got {mirror!r})")
    # Only substitute the github.com host so that paths remain intact.
    for prefix in ("https://github.com", "https://objects.githubusercontent.com"):
        if url.startswith(prefix):
            return mirror.rstrip("/") + url[len(prefix) :]
    return url


# ---------- Download + verify --------------------------------------------- #


def _ssl_context() -> ssl.SSLContext | None:
    """Return Headroom's configured SSL context for urllib.request.urlopen, or
    ``None`` (urlopen's default) when the trust helper cannot be loaded.

    This ensures binary downloads from GitHub releases (and any configured
    mirror) trust the same roots as the proxy — including corporate
    TLS-inspection roots installed in the OS store and bundles referenced via
    ``HEADROOM_CA_BUNDLE`` / ``SSL_CERT_FILE``. Without this, ``uv tool``
    installs (where certifi may not yet be wired to the stdlib path) raise
    ``CERTIFICATE_VERIFY_FAILED`` even though certifi is already a dependency.
    """
    try:
        from headroom.proxy.ssl_context import build_urlopen_context
    except ImportError:
        return None

    return build_urlopen_context()


def _download(url: str, dest: Path, *, progress: bool = True) -> None:
    if os.environ.get("HEADROOM_BINARIES_OFFLINE"):
        raise OfflineError(f"offline mode (HEADROOM_BINARIES_OFFLINE=1) but fetch required: {url}")
    # HEADROOM_BINARIES_OFFLINE above is the narrow, binaries-only switch; this
    # is the deployment-wide one. An operator who set the air-gap switch should
    # not have to also discover a second, differently-named flag to stop
    # Headroom fetching release assets from GitHub at install time.
    guard_egress("release binary download", url)
    if not _has_writable_existing_parent(dest.parent):
        raise OSError(f"binary cache directory parent is not writable: {dest.parent}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not _is_writable_dir(dest.parent):
        raise OSError(f"binary cache directory is not writable: {dest.parent}")
    final_url = _mirror_url(url)
    if not final_url.startswith("https://"):
        raise BinaryFetchError(f"refusing non-https download URL: {final_url!r}")
    req = urllib.request.Request(final_url, headers={"User-Agent": "headroom-binaries/1"})
    try:
        ctx = _ssl_context()
    except Exception as e:
        raise BinaryFetchError(f"failed to configure TLS trust for binary download: {e}") from e
    attempts = 3
    for attempt in range(1, attempts + 1):
        try:
            if ctx is not None:
                resp = urllib.request.urlopen(req, timeout=60, context=ctx)  # noqa: S310 (https)
            else:
                resp = urllib.request.urlopen(req, timeout=60)  # noqa: S310 (https)
            with resp:
                total = int(resp.headers.get("Content-Length") or 0)
                _stream_to(resp, dest, total, label=dest.name, show_progress=progress)
            return
        except urllib.error.URLError as e:
            dest.unlink(missing_ok=True)
            if attempt == attempts:
                raise BinaryFetchError(
                    f"failed to download {final_url} after {attempts} attempts: {e}"
                ) from e
            # GitHub release assets occasionally return a transient 5xx or
            # reset while redirecting to the object store. A short bounded
            # retry keeps proxy startup reliable without hiding persistent
            # credential, mirror, or connectivity failures.
            time.sleep(0.25 * attempt)


def _stream_to(src: Any, dest: Path, total: int, *, label: str, show_progress: bool) -> None:
    # Rich progress if available and stderr is a tty; otherwise silent chunked copy.
    try:
        if show_progress and sys.stderr.isatty():
            from rich.progress import (
                BarColumn,
                DownloadColumn,
                Progress,
                TextColumn,
                TimeRemainingColumn,
                TransferSpeedColumn,
            )

            with Progress(
                TextColumn("[bold blue]{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TransferSpeedColumn(),
                TimeRemainingColumn(),
            ) as prog:
                task = prog.add_task(label, total=total or None)
                with dest.open("wb") as out:
                    while chunk := src.read(1024 * 64):
                        out.write(chunk)
                        prog.update(task, advance=len(chunk))
            return
    except ImportError:
        pass
    with dest.open("wb") as out:
        shutil.copyfileobj(src, out)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 64), b""):
            h.update(chunk)
    return h.hexdigest()


def _allow_unverified(name: str) -> bool:
    """True if the escape hatch is set — announced loudly each time it fires.

    Skipping verification turns a supply-chain guarantee into transport trust,
    so it goes to stderr as well as the logger: the logger is frequently
    unconfigured at proxy startup, and a silent downgrade is the failure mode
    this whole module exists to avoid.

    Exactly once, though. With no handlers configured, logging's ``lastResort``
    already writes WARNING to stderr, so printing unconditionally produced the
    same sentence twice. Print only when a handler exists -- that is precisely
    when ``lastResort`` will not fire, and when the log may be going somewhere
    an operator is not watching, such as a file.
    """
    if not os.environ.get("HEADROOM_BINARIES_ALLOW_UNVERIFIED"):
        return False
    message = (
        f"headroom: WARNING: accepting {name} WITHOUT sha256 verification "
        "(HEADROOM_BINARIES_ALLOW_UNVERIFIED is set). A tampered or "
        "substituted binary will not be detected."
    )
    logger.warning("%s", message)
    if logger.hasHandlers():
        print(message, file=sys.stderr)
    return True


def _verify_sha256(path: Path, expected: str | None) -> None:
    if _allow_unverified(path.name):
        return
    if not expected:
        # No pin in the registry. All shipped assets ARE pinned — enforced by
        # the tools-hash-refresh CI gate — so a missing pin means an
        # off-registry fetch. Fail closed: HTTPS proves only who served the
        # bytes, not that they are the bytes we pinned.
        path.unlink(missing_ok=True)
        raise UnpinnedDownload(
            f"refusing unpinned download {path.name}: no sha256 in the registry. "
            "Pin it in headroom/tools.json (scripts/refresh_tool_hashes.py), or set "
            "HEADROOM_BINARIES_ALLOW_UNVERIFIED=1 to accept it unverified."
        )
    got = _sha256_file(path)
    if got.lower() != expected.lower():
        path.unlink(missing_ok=True)
        raise Sha256Mismatch(f"sha256 mismatch for {path.name}: expected {expected}, got {got}")


def sha256_for_url(url: str) -> str | None:
    """Return the registry's pinned sha256 for a download URL, if present."""
    for tool in _registry().get("tools", {}).values():
        for asset in tool.get("assets", {}).values():
            if asset.get("url") == url:
                pin = asset.get("sha256")
                return pin if isinstance(pin, str) else None
    return None


def verify_download_bytes(data: bytes, *, url: str, name: str) -> None:
    """Fail-closed integrity check for an in-memory downloaded archive.

    Used by installers (codebase-memory-mcp) that download and extract on their
    own instead of going through the fetch path above. Verifies the bytes
    against the tools.json pin for ``url``.

    Raises UnpinnedDownload if ``url`` has no pin in the registry and
    Sha256Mismatch if the bytes do not match it. Setting
    HEADROOM_BINARIES_ALLOW_UNVERIFIED=1 skips both checks.
    """
    if _allow_unverified(name):
        return
    expected = sha256_for_url(url)
    if not expected:
        # Off-registry URL — a version override, or an installer building a
        # filename the registry does not carry. Refuse rather than silently
        # downgrading to transport trust.
        raise UnpinnedDownload(
            f"refusing unpinned download {name}: {url} has no sha256 in the registry. "
            "Pin it in headroom/tools.json (scripts/refresh_tool_hashes.py), or set "
            "HEADROOM_BINARIES_ALLOW_UNVERIFIED=1 to accept it unverified."
        )
    got = hashlib.sha256(data).hexdigest()
    if got.lower() != expected.lower():
        raise Sha256Mismatch(f"sha256 mismatch for {name}: expected {expected}, got {got}")


# ---------- Archive extraction ------------------------------------------- #


def _extract(archive: Path, member: str, dest: Path) -> None:
    """Extract `member` from archive into `dest` (single-file binary)."""
    if not _has_writable_existing_parent(dest.parent):
        raise OSError(f"binary cache directory parent is not writable: {dest.parent}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not _is_writable_dir(dest.parent):
        raise OSError(f"binary cache directory is not writable: {dest.parent}")
    name = archive.name.lower()
    try:
        if name.endswith(".tar.gz") or name.endswith(".tgz"):
            with tarfile.open(archive, "r:gz") as tf:
                _extract_member_from_tar(tf, member, dest)
        elif name.endswith(".zip"):
            with zipfile.ZipFile(archive) as zf:
                _extract_member_from_zip(zf, member, dest)
        elif name.endswith(".gz") and not (name.endswith(".tar.gz") or name.endswith(".tgz")):
            # bare .gz of a single binary (e.g. `scc-linux-x86_64.gz`)
            import gzip

            with gzip.open(archive, "rb") as gz, dest.open("wb") as out:
                shutil.copyfileobj(gz, out)
        else:
            # Not an archive — treat the downloaded file itself as the binary.
            shutil.copy2(archive, dest)
    except (tarfile.TarError, zipfile.BadZipFile, OSError) as e:
        raise BinaryFetchError(f"failed to extract {archive.name}: {e}") from e


def _extract_member_from_tar(tf: tarfile.TarFile, member: str, dest: Path) -> None:
    # Match by basename so that registries can specify "difft" even though the
    # upstream tar may include a leading directory like "difft-0.64.0/difft".
    wanted = member.lower()
    for m in tf.getmembers():
        base = m.name.rsplit("/", 1)[-1].lower()
        if base == wanted and m.isfile():
            extracted = tf.extractfile(m)
            if extracted is None:
                continue
            with dest.open("wb") as out:
                shutil.copyfileobj(extracted, out)
            return
    raise BinaryFetchError(f"archive did not contain expected member {member!r}")


def _extract_member_from_zip(zf: zipfile.ZipFile, member: str, dest: Path) -> None:
    wanted = member.lower()
    for info in zf.infolist():
        base = info.filename.rsplit("/", 1)[-1].lower()
        if base == wanted and not info.is_dir():
            with zf.open(info) as src, dest.open("wb") as out:
                shutil.copyfileobj(src, out)
            return
    raise BinaryFetchError(f"archive did not contain expected member {member!r}")


# ---------- Public API ---------------------------------------------------- #


def _binary_name(tool: str, plat: PlatformKey) -> str:
    entry = _tool_entry(tool)
    base = entry.get("binary", tool)
    return f"{base}.exe" if plat.os == "windows" else base


def _cached_path(tool: str, version: str, plat: PlatformKey) -> Path:
    return cache_dir() / f"{tool}-{version}-{plat.key()}" / _binary_name(tool, plat)


def _in_registry(tool: str) -> bool:
    return tool in _registry().get("tools", {})


def _path_lookup(tool: str) -> Path | None:
    """Find `tool` on PATH or in this interpreter's Scripts/bin directory.

    PyPI binary wheels (e.g. ast-grep-cli) install their console scripts into
    sys.prefix/bin (or sys.prefix/Scripts on Windows). That directory is on
    PATH when the venv is activated, but subprocesses started by a non-active
    interpreter can miss it, so we check it explicitly as a fallback.
    """
    candidates = [tool]
    if _in_registry(tool):
        alias = _tool_entry(tool).get("binary")
        if alias and alias != tool:
            candidates.append(alias)

    for name in candidates:
        found = shutil.which(name)
        if found:
            return Path(found)

    scripts_dir = Path(sys.prefix) / ("Scripts" if sys.platform.startswith("win") else "bin")
    for name in candidates:
        exe = scripts_dir / (name + (".exe" if sys.platform.startswith("win") else ""))
        if exe.exists():
            return exe
    return None


def which(tool: str) -> Path | None:
    """Return a path to `tool` if it is on PATH or already cached, else None.

    Never triggers a network fetch. Callers that want the tool to be installed
    on demand should use `resolve()` instead.
    """
    on_path = _path_lookup(tool)
    if on_path:
        return on_path
    if not _in_registry(tool):
        return None
    try:
        plat = detect_platform()
        _asset_for_platform(tool, plat)  # raises if unsupported
    except PlatformNotSupported:
        return None
    path = _cached_path(tool, _tool_entry(tool)["version"], plat)
    return path if path.exists() else None


def resolve(tool: str) -> Path:
    """Return a path to the tool binary, fetching it on first use.

    Raises PlatformNotSupported if the tool is unavailable on this platform,
    OfflineError if a fetch is required but HEADROOM_BINARIES_OFFLINE is set,
    Sha256Mismatch if verification fails, UnpinnedDownload if the asset carries
    no registry pin, BinaryFetchError on other IO errors.
    """
    on_path = _path_lookup(tool)
    if on_path:
        return on_path
    if not _in_registry(tool):
        raise KeyError(f"unknown tool {tool!r}")

    plat = detect_platform()
    entry = _tool_entry(tool)
    asset = _asset_for_platform(tool, plat)
    version = entry["version"]
    binary_path = _cached_path(tool, version, plat)
    if binary_path.exists():
        return binary_path

    # Not cached — fetch, verify, extract.
    url = asset["url"]
    sha256 = asset.get("sha256")
    member = asset.get("member", _binary_name(tool, plat))

    with tempfile.TemporaryDirectory(prefix="headroom-fetch-") as tmp:
        tmp_dir = Path(tmp)
        # Strip query params so mirror URLs like `.../difft.tar.gz?token=...`
        # don't produce filenames that break archive-type detection.
        url_path = urllib.parse.urlparse(url).path
        download_path = tmp_dir / (Path(url_path).name or "download")
        _download(url, download_path)
        _verify_sha256(download_path, sha256)
        staging = tmp_dir / "out"
        _extract(download_path, member, staging)
        binary_path.parent.mkdir(parents=True, exist_ok=True)
        # Atomic move with a PID-scoped partial name so two concurrent
        # `headroom proxy` starts don't race on the same .partial path.
        tmp_final = binary_path.with_name(f"{binary_path.name}.{os.getpid()}.partial")
        shutil.move(str(staging), tmp_final)
        try:
            tmp_final.chmod(0o755)
        except OSError as e:
            if not sys.platform.startswith("win"):
                logger.warning("chmod +x failed for %s: %s", tmp_final, e)
            # On Windows the .exe is already executable; elsewhere we logged.
        os.replace(tmp_final, binary_path)
    return binary_path


def ensure_tools(quiet: bool = False) -> dict[str, Path | None]:
    if not _has_writable_existing_parent(cache_dir()):
        return {name: which(name) for name in _registry().get("tools", {})}
    """Install every tool in the registry if missing. Safe to call repeatedly.

    Called at proxy startup and on first `headroom` CLI invocation so that no
    tool fetch ever happens inside a live request. Skips tools that are on
    PATH, already cached, or distributed via PyPI-only (ast-grep).

    Returns a map of tool_name -> resolved Path (or None if unsupported).
    Never raises; unsupported platforms or offline errors are logged via
    stderr and the tool is skipped.
    """
    out: dict[str, Path | None] = {}
    for name in _registry().get("tools", {}):
        try:
            if _is_pypi_tool(name):
                # ast-grep ships via pip; just record whether it's on PATH.
                out[name] = _path_lookup(name)
                continue
            out[name] = resolve(name)
        except (
            PlatformNotSupported,
            OfflineError,
            BinaryFetchError,
            Sha256Mismatch,
            # An unpinned asset is refused, not installed. Startup still
            # degrades to "tool missing" rather than failing outright.
            UnpinnedDownload,
            # Catch readonly / sandboxed filesystems (e.g. containerized
            # home dirs) so proxy startup never fails because the cache dir
            # can't be created. The interceptor fall back to no-op.
            OSError,
        ) as e:
            out[name] = None
            if not quiet:
                print(f"headroom: skipping {name}: {e}", file=sys.stderr)
    return out


def status() -> list[dict[str, Any]]:
    """Return a list of status dicts for every tool in the registry.

    Used by `headroom tools doctor`. Never fetches — only inspects.
    """
    out: list[dict[str, Any]] = []
    plat = detect_platform()
    for name, entry in _registry().get("tools", {}).items():
        row: dict[str, Any] = {
            "tool": name,
            "version": entry.get("version"),
            "platform": plat.key(),
            "source": entry.get("source", "fetched"),
            "path": None,
            "state": "missing",
        }
        # Honor PATH.
        on_path = shutil.which(name) or (
            shutil.which(entry["binary"]) if entry.get("binary") else None
        )
        if on_path:
            row["path"] = on_path
            row["state"] = "on-path"
            out.append(row)
            continue
        try:
            asset = _asset_for_platform(name, plat)
        except PlatformNotSupported as e:
            row["state"] = "unsupported-platform"
            row["detail"] = str(e)
            out.append(row)
            continue
        row["sha_pinned"] = bool(asset.get("sha256"))
        cached = _cached_path(name, entry["version"], plat)
        if cached.exists():
            row["path"] = str(cached)
            row["state"] = "cached"
        out.append(row)
    return out
