"""Pricing module for LLM cost estimation.

This module provides pricing information and cost estimation utilities
for various LLM providers. Uses LiteLLM's community-maintained pricing
database for up-to-date costs across 100+ models.
"""

# Legacy imports for backwards compatibility
from .anthropic_prices import (
    ANTHROPIC_PRICES,
    get_anthropic_registry,
)
from .anthropic_prices import (
    LAST_UPDATED as ANTHROPIC_LAST_UPDATED,
)
from .cache_ttl import (
    CACHE_READ_MULTIPLIER,
    CACHE_WRITE_MULTIPLIERS,
    DEFAULT_CACHE_TTL,
    CacheTTL,
    cache_rates_per_1m,
    cache_write_multiplier,
    ttl_breakeven_share,
)
from .deepseek_prices import (
    DEEPSEEK_PRICES,
    get_deepseek_registry,
)
from .deepseek_prices import (
    LAST_UPDATED as DEEPSEEK_LAST_UPDATED,
)
from .deepseek_tiers import (
    OFF_PEAK_RATES_PER_1M,
    PEAK_MULTIPLIER,
    WEEKEND_OFF_PEAK_FROM,
    DeepSeekRates,
    bare_model,
    is_peak,
    off_peak_rates,
    rates_for,
)
from .litellm_pricing import (
    LiteLLMModelPricing,
    estimate_cost,
    get_litellm_model_cost,
    get_model_pricing,
    list_available_models,
)
from .openai_prices import (
    LAST_UPDATED as OPENAI_LAST_UPDATED,
)
from .openai_prices import (
    OPENAI_PRICES,
    get_openai_registry,
)
from .registry import CostEstimate, ModelPricing, PricingRegistry

__all__ = [
    # Prompt-cache TTL structure (read / 5m write / 1h write)
    "CACHE_READ_MULTIPLIER",
    "CACHE_WRITE_MULTIPLIERS",
    "DEFAULT_CACHE_TTL",
    "CacheTTL",
    "cache_rates_per_1m",
    "cache_write_multiplier",
    "ttl_breakeven_share",
    # LiteLLM-based pricing (preferred)
    "LiteLLMModelPricing",
    "estimate_cost",
    "get_litellm_model_cost",
    "get_model_pricing",
    "list_available_models",
    # Core classes
    "CostEstimate",
    "ModelPricing",
    "PricingRegistry",
    # Legacy - OpenAI (deprecated, use LiteLLM instead)
    "OPENAI_LAST_UPDATED",
    "OPENAI_PRICES",
    "get_openai_registry",
    # Legacy - Anthropic (deprecated, use LiteLLM instead)
    "ANTHROPIC_LAST_UPDATED",
    "ANTHROPIC_PRICES",
    "get_anthropic_registry",
    # DeepSeek
    "DEEPSEEK_LAST_UPDATED",
    "DEEPSEEK_PRICES",
    "get_deepseek_registry",
    # DeepSeek peak/off-peak structure (Beijing windows; peak = 2x off-peak)
    "OFF_PEAK_RATES_PER_1M",
    "PEAK_MULTIPLIER",
    "WEEKEND_OFF_PEAK_FROM",
    "DeepSeekRates",
    "bare_model",
    "is_peak",
    "off_peak_rates",
    "rates_for",
]
