"""OpenCode install-time helpers."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from headroom import fsutil
from headroom.install.models import ConfigScope, DeploymentManifest, ManagedMutation, ToolTarget
from headroom.install.paths import opencode_config_path

from .config import (
    _inject_key_into_json,
    _parse_json_loose,
    load_user_opencode_config,
    migrate_legacy_opencode_jsonc_backup,
    snapshot_opencode_config_if_unwrapped,
    strip_opencode_headroom_blocks,
)
from .runtime import proxy_base_url


def build_install_env(*, port: int, backend: str) -> dict[str, str]:
    """Build the persistent install environment for OpenCode."""
    del backend
    del port
    return {}


def apply_provider_scope(manifest: DeploymentManifest) -> ManagedMutation | None:
    """Apply OpenCode provider-scope configuration when requested."""
    if manifest.scope != ConfigScope.PROVIDER.value:
        return None

    config_file = opencode_config_path()
    config_file.parent.mkdir(parents=True, exist_ok=True)
    backup_file = config_file.with_name(config_file.name + ".headroom-backup")
    migrate_legacy_opencode_jsonc_backup(config_file, backup_file)
    snapshot_opencode_config_if_unwrapped(config_file, backup_file)

    if config_file.exists():
        content = fsutil.read_text(config_file)
        data = load_user_opencode_config(content, config_file)
    else:
        data = {}

    provider = {
        "headroom": {
            "npm": "@ai-sdk/openai-compatible",
            "name": "Headroom Proxy",
            "options": {"baseURL": proxy_base_url(manifest.port)},
        }
    }
    data = _inject_key_into_json(data, "provider", provider)

    config_file.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
    return ManagedMutation(
        target=ToolTarget.OPENCODE.value,
        kind="json-block",
        path=str(config_file),
    )


def restore_opencode_backup(config_path: str, backup_path: str) -> None:
    """Restore the owned OpenCode snapshot, if it still exists."""
    path = Path(config_path)
    backup_file = Path(backup_path)
    migrate_legacy_opencode_jsonc_backup(path, backup_file)
    if backup_file.exists():
        shutil.copy2(backup_file, path)
        backup_file.unlink()


def revert_provider_scope(
    mutation: ManagedMutation,
    manifest: DeploymentManifest,
    *,
    restore_backup: bool = True,
) -> None:
    """Undo OpenCode provider-scope configuration.

    Final removal restores the pre-install snapshot when available. Temporary
    deactivation removes only the managed provider and retains that snapshot.
    """
    del manifest
    if not mutation.path:
        return
    path = Path(mutation.path)
    backup_file = path.with_name(path.name + ".headroom-backup")
    migrate_legacy_opencode_jsonc_backup(path, backup_file)
    if restore_backup and backup_file.exists():
        try:
            restore_opencode_backup(str(path), str(backup_file))
            return
        except OSError:
            pass
    if not path.exists():
        return
    content = fsutil.read_text(path)
    data = _parse_json_loose(content)
    providers = data.get("provider")
    if isinstance(providers, dict) and "headroom" in providers:
        providers.pop("headroom")
        if not providers:
            data.pop("provider", None)
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
        return
    cleaned = strip_opencode_headroom_blocks(content)
    if cleaned != content.strip():
        path.write_text(cleaned + "\n", encoding="utf-8", newline="\n")
    elif not data and not content.strip():
        path.unlink(missing_ok=True)
