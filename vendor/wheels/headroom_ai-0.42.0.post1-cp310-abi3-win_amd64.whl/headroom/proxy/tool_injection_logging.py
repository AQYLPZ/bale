"""Logging policy for proxy tool-injection decisions."""

from __future__ import annotations

import logging
from typing import Literal

ToolInjectionDecision = Literal[
    "inject_first_time",
    "inject_sticky_replay",
    # CCR, eager mode (the default): the retrieval tool is injected on the
    # session's first request, before anything has been compressed, so the
    # tools array — the head of the provider cache key — never changes
    # mid-session. Distinguished from inject_first_time so operators can tell
    # "entered the array cold" from "entered it against a warm prefix".
    "inject_eager",
    # Sessionless path: history already references headroom_retrieve, so the
    # tool definition is re-injected even without fresh compression (#2440).
    "inject_history_reference",
    "skip",
    "skip_no_client_tools",
    "skip_disabled_via_env",
]


def log_tool_injection_decision(
    *,
    logger: logging.Logger,
    provider: str,
    session_id: str | None,
    decision: ToolInjectionDecision,
    tool_definition_bytes_count: int,
    request_id: str | None,
) -> None:
    """Emit a cache-affecting tool-injection decision without tool contents."""

    logger.info(
        "event=tool_injection_decision provider=%s session_id=%s "
        "decision=%s tool_definition_bytes_count=%d request_id=%s",
        provider,
        session_id or "",
        decision,
        tool_definition_bytes_count,
        request_id or "",
    )
